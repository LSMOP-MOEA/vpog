classdef VPOG < ALGORITHM
% <multi/many> <real> <large/none>
% Direction guided evolutionary algorithm
% operation ---   1 --- Operation of the environmental selection
% k     ---  10 --- Number of reference vectors for offspring generation


    methods
        function main(Algorithm,Problem)
            %% Generate random population
            [operation, k]= Algorithm.ParameterSet(1, 10);
            [V,Problem.N] = UniformPoint(Problem.N,Problem.M);
            Population    = Problem.Initialization();
            Offspring     = Problem.Initialization();
            Arc           = Population;

            %% Optimization
            while Algorithm.NotTerminated(Arc)
                [Population,FrontNo] = PreSelection([Population,Offspring],V,(Problem.FE/Problem.maxFE)^2,k);
                Offspring = DirectionReproduction(Problem,Population,FrontNo,k);
%                  Arc     = EnvironmentalSelection([Population,Offspring],V,(Problem.FE/Problem.maxFE)^2);
                switch operation
                    case 0
                        Arc = [Population,Offspring]; % Without selection
                    case 1 
                        Arc = subRVEA([Arc,Offspring],V,(Problem.FE/Problem.maxFE)^2);
                    case 2
                        Arc = subNSGAII([Arc,Offspring],Problem.N);
                    case 3 
                        Arc = subIBEA([Arc,Offspring],Problem.N,0.05);
                    case 4 
                        Arc = subSPEA2([Arc,Offspring],Problem.N);
                end
            end
        end
    end
end