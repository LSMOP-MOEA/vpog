function [Population, FrontNo] = PreSelection(Population,V,theta,RefNo)



    %% Preseleting some  well-converged solutions 预选一些好的解
    % RefNo =10
    
    NV     = size(V,1);
    [Front,MaxFront] = NDSort(Population.objs,min([NV,length(Population)]));%非支配排序
    if  sum(Front==1) >= RefNo  %最前沿解的个数小于 方向向量数量
        Next0 = Front < MaxFront;
        Last = find(Front == MaxFront);
    else                         %最前沿解的个数大于 方向向量数量
        Next0 = Front == 1;
        Last = find(Front >1);
    end
    
    %    k=RefNo;
   % [idx,C] = kmeans(Population.objs,k);

    %% Selecting those diversity-related but well-converged solutions 多样性的解
    PopObj = Population(Last).objs;
    [N,M]  = size(PopObj);

    %% Translate the population  减去最小值
    PopObj = PopObj - repmat(min(Population.objs,[],1),N,1);
    
    %% Calculate the smallest angle value between each vector and others 计算最小角度
    cosine = 1 - pdist2(V,V,'cosine');
    cosine(logical(eye(length(cosine)))) = 0;
    gamma  = min(acos(cosine),[],2);

    %% Associate each solution to a reference vector 将每个解决方案与参考向量相关联
    Angle = acos(1-pdist2(PopObj,V,'cosine'));
    [~,associate] = min(Angle,[],2);

    %%  Select one solution for each reference vector 为每个参考向量选择一个解决方案
    % 为每个参考向量选择一个解决方案
    Next = zeros(1,NV);
    for i = unique(associate)'
        current = find(associate==i);
        % Calculate the APD value of each solution
        APD = (1+M*theta*Angle(current,i)/gamma(i)).*sqrt(sum(PopObj(current,:).^2,2));
        % Select the one with the minimum APD value
        [~,best] = min(APD);
        Next(i) = current(best);
    end
    % Population for next generation 下一代种群
    Next0(Last(Next(Next~=0))) = true;
    Population = Population(Next0);
    FrontNo = Front(Next0);
end