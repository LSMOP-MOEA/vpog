function Population = subNSGAII(Population,N)
% The environmental selection of NSGA-II



    %% Non-dominated sorting
    CC = min([N,length(Population)]);
    [FrontNo,MaxFNo] = NDSort(Population.objs,Population.cons,CC);
    Next = FrontNo < MaxFNo;
    
    %% Calculate the crowding distance of each solution
    CrowdDis = CrowdingDistance(Population.objs,FrontNo);
    
    %% Select the solutions in the last front based on their crowding distances
    Last     = find(FrontNo==MaxFNo);
    [~,Rank] = sort(CrowdDis(Last),'descend');
    Next(Last(Rank(1:CC-sum(Next)))) = true;
    
    %% Population for next generation
    Population = Population(Next);
end