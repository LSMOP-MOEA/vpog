function Offspring = DirectionReproduction(Problem,Population,FrontNo,k)

% 聚类选择k

	[N,D]   = size(Population.decs);
    indexD  = find(FrontNo>1);
    
    domiN   = numel(indexD);
    indexN  = FrontNo == 1;
	nondec  = Population(indexN).decs;
    domidec = Population(indexD).decs;  
	subN    = max([floor(Problem.N/k),10]);
    Lower   = repmat(Problem.lower,subN,1);
    Upper   = repmat(Problem.upper,subN,1);
    PopDec  = [];

   
    %% Select direction solutions  选择方向解
    startP = nondec(randperm(N-domiN,1),:);
    if domiN < k  % 被支配解（差解） < 参考向量数
        %This part increases the convergence
        if N <= k % 原始种群数 < 参考向量数
            endP = [domidec;nondec(randperm(N-domiN,N-domiN),:)];
        else
            endP = [domidec;nondec(randperm(N-domiN,k-domiN),:)];
        end
    else %（差解） > 参考向量数
        
%         PopObj = PopObj - repmat(min(Population.objs,[],1),N,1);
    
%     %% Calculate the smallest angle value between each vector and others 计算最小角度
%     cosine = 1 - pdist2(V,V,'cosine');
%     cosine(logical(eye(length(cosine)))) = 0;
%     gamma  = min(acos(cosine),[],2);
    
        % This part increase the diversity 这部分增加了多样性,修改，做聚类，找最近的向量
       %k=k;%10
       [idx,C] = kmeans(Population(indexD).objs,k);
       clustering_id=zeros(1,k);
       for i=1:k  
           Local_index = indexD(find(idx==i));

           [~,num] =size(Local_index);
           sigma_list=zeros(1,num);
           for j=1:num
                m=Local_index(j);
                number=acos((Population(m).objs*(C(i,:).'))/(norm(Population(m).objs)*norm(C(i,:)))); %向量和聚类中心夹角，最小的值
                sigma_list(1,j) = number;
           end
           [~,min_I] = min(sigma_list);
           clustering_id(1,i)=Local_index(min_I);
       end
       endP = Population(clustering_id).decs;
%    %endP = domidec(randperm(domiN,RefNo),:);
   
%  % This part increase the diversity 这部分增加了多样性,修改，做聚类，找最近的向量
%        k=RefNo;%10
%        [idx,C] = kmeans(Population(indexD).objs,k);
%        clustering_id=zeros(1,k);
%        for i=1:k  
%            Local_index = indexD(find(idx==i));
% 
%            [~,num] =size(Local_index);
%            sigma_list=zeros(1,num);
%            for j=1:num
%                 m=Local_index(j);
%                 number=acos((Population(m).objs*(C(i,:).'))/(norm(Population(m).objs)*norm(C(i,:)))); %向量和聚类中心夹角，最小的值
%                 sigma_list(1,j) = number;
%            end
%            [~,min_I] = min(sigma_list);
%            clustering_id(1,i)=Local_index(min_I);
%        end
%        endP = Population(clustering_id).decs;
 
    end
    
    k   = size(endP,1);
    vector  = (endP - repmat(startP,k,1));  
    Direct  = vector./repmat(sum(vector.^2,2).^(1/2),1,D);
    for i = 1 : k
        lambda  = (nondec - repmat(startP,N-domiN,1))*Direct(i,:)';
        sigma   = std(lambda)*(1+((domiN+1)/N)^1);
        roundNum=rand();
        
        OffDec  = repmat(normrnd(0,sigma,[subN,1]),1,D).*repmat(Direct(i,:),subN,1)*(1+roundNum)+repmat(startP,subN,1);
        OffDec=1*OffDec;
        PopDec  = [PopDec;max(min(OffDec,Upper),Lower)];
    end

    %% Polynomial mutation 多项式变异
	OffDec = PopDec;
    N      = size(OffDec,1);
    Lower  = repmat(Problem.lower,N,1);
    Upper  = repmat(Problem.upper,N,1);
    disM   = 20;
    Site   = rand(N,D) < 1/Problem.D;
    mu     = rand(N,D);
    temp   = Site & mu<=0.5;
    OffDec = max(min(OffDec,Upper),Lower);
    OffDec(temp) = OffDec(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                   (1-(OffDec(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
    temp  = Site & mu>0.5; 
    OffDec(temp) = OffDec(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                   (1-(Upper(temp)-OffDec(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
	Offspring = SOLUTION(OffDec);
end